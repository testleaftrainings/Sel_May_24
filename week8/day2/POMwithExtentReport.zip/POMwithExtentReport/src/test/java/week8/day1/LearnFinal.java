package week8.day1;

public class LearnFinal  {

	public  void add() {
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LearnFinalKeyword lc=new LearnFinalKeyword();
		
	}

}
