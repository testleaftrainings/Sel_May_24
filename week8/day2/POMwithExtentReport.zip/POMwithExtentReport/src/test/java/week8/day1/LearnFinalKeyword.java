package week8.day1;

public  final class LearnFinalKeyword {

	
	public final void add() {
		System.out.println("final method");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
final int  data=5;
	}

}
