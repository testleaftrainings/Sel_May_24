package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import config.Configuration;

public class MyHomePage extends BaseClass {

	
	public MyLeads clickOnLeadsButton() {
		
		String clickonLead = Configuration.configuartion().clickonLead();
		
		getDriver().findElement(By.linkText(clickonLead)).click();
		return new MyLeads();
	}
}
