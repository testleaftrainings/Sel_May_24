package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass{

	
	@Given("Enter the username as {string}")
	public LoginPage enterTheUsername(String uName) {
		getDriver().findElement(By.id("username")).sendKeys(uName);
		//m1
		//LoginPage lp=new LoginPage();
		//return lp;
		
		//m2
		return this;
	
	}
	
	@Given("Enter the password as {string}")
	public LoginPage enterThePassword(String pass) {
		getDriver().findElement(By.id("password")).sendKeys(pass);
		return this;
	}
	
	@When("Click on Login Button")
	public HomePage clickOnLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		
		//m1
		//HomePage hp=new HomePage();
		//return hp;
		
		//m2
		return new HomePage();

	}
	
	@Then("Verify the page")
	public void verify_the_page() {
		String title = getDriver().getTitle();
		  if(title.contains("Testleaf")) {
			  System.out.println("Login is successfull");
		  }else {
			  System.out.println("Login is not Successfull");
		  }
	}
	
}
