package config;

public class GetdData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Encapsulation e=new Encapsulation();
e.getCardPin();
e.setCardPin(3456);

	}

}
