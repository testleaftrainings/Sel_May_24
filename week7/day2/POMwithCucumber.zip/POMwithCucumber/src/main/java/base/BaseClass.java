package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.IntegrationWIthTC;


public class BaseClass  extends AbstractTestNGCucumberTests{

	private static final ThreadLocal<RemoteWebDriver> tlDriver=new ThreadLocal<RemoteWebDriver>();
	
	public void setDriver() {
		tlDriver.set(new ChromeDriver());
	}
	
	public RemoteWebDriver getDriver() {
		return tlDriver.get();
	}
	
	
	
	public String dataFile;
	
	@BeforeMethod
	public void perSetUp() {
setDriver();
getDriver().manage().window().maximize();
getDriver().get("http://leaftaps.com/opentaps/control/main");
getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
	}
	
	
	@AfterMethod
	public void postSetUp() {
		getDriver().quit();	
	}
	
	@DataProvider(name="getValue")
	public String[][] fetchData() throws IOException {	
		
		return IntegrationWIthTC.readExcel(dataFile);
	
	}


	
	
}
